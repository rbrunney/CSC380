package com.example.retrovideogameexchangeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetroVideoGameExchangeApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(RetroVideoGameExchangeApiApplication.class, args);
    }

}
