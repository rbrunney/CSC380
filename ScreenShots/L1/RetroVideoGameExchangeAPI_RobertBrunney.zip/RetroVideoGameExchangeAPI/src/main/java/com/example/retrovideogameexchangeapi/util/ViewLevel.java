package com.example.retrovideogameexchangeapi.util;

public interface ViewLevel {

    public class PublicView {}
    public class InternalView extends PublicView {}
}
