package com.example.retrovideogameexchangeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetroVideoGameExchangeApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
